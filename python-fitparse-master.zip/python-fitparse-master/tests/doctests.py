import doctest

doctest.testfile('api_examples.txt')
